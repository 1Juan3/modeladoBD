CREATE TABLE `veterinaria` (
  `id_veterinaria` int PRIMARY KEY,
  `nombre` varchar(255)
);

CREATE TABLE `producto` (
  `id_producto` int PRIMARY KEY,
  `nombre` varchar(255),
  `descripcion` varchar(255),
  `stock` int,
  `precio` double,
  `imagen` varchar(255)
);

CREATE TABLE `producto_veterinaria` (
  `id_producto_veterinaria` int PRIMARY KEY,
  `id_veterinaria1` int,
  `id_producto1` int
);

CREATE TABLE `servicio` (
  `id_servicio` int PRIMARY KEY,
  `nombre_s` varchar(255),
  `descripcion` varchar(255),
  `precio` double
);

CREATE TABLE `servicio_veterinaria` (
  `id_servicio_veterinaria` int PRIMARY KEY,
  `id_veterinaria2` int,
  `id_servicio1` int
);

CREATE TABLE `veterinarioV` (
  `id_veterinarioV` int PRIMARY KEY,
  `nombreV` varchar(255),
  `descripcion` varchar(255),
  `id_veterinaria3` int
);

CREATE TABLE `veterinario` (
  `id_veterinario` int PRIMARY KEY,
  `nombre` varchar(255),
  `telefono` varchar(255)
);

CREATE TABLE `cliente` (
  `id_cliente` int PRIMARY KEY,
  `nombre` varchar(100),
  `apellidos` varchar(100),
  `direccion` varchar(100),
  `telefono` varchar(20)
);

CREATE TABLE `disponibilidad` (
  `id_disponibilidad` int PRIMARY KEY,
  `fecha` date,
  `hora_inicio` time,
  `hora_final` time,
  `veterinario_id` int
);

CREATE TABLE `cita` (
  `id_cita` int PRIMARY KEY,
  `fecha` date,
  `hora` time,
  `veterinario_id1` int,
  `cliente_id` int,
  `disponibilidad_id` int
);

CREATE TABLE `pedido` (
  `id_pedido` int PRIMARY KEY,
  `fecha` date,
  `hora` time,
  `cliente_id1` int,
  `producto_id` int,
  `cantidad` int
);

CREATE TABLE `domiciliario` (
  `id_domiciliario` int PRIMARY KEY,
  `nombre` varchar(255),
  `telefono` varchar(20)
);

CREATE TABLE `factura` (
  `id_factura` int PRIMARY KEY,
  `fecha` date,
  `pedido_id1` int,
  `total` double,
  `domiciliario_id` int
);

ALTER TABLE `veterinarioV` ADD FOREIGN KEY (`id_veterinaria3`) REFERENCES `veterinaria` (`id_veterinaria`);

ALTER TABLE `servicio_veterinaria` ADD FOREIGN KEY (`id_veterinaria2`) REFERENCES `veterinaria` (`id_veterinaria`);

ALTER TABLE `servicio_veterinaria` ADD FOREIGN KEY (`id_servicio1`) REFERENCES `servicio` (`id_servicio`);

ALTER TABLE `producto_veterinaria` ADD FOREIGN KEY (`id_producto1`) REFERENCES `producto` (`id_producto`);

ALTER TABLE `producto_veterinaria` ADD FOREIGN KEY (`id_veterinaria1`) REFERENCES `veterinaria` (`id_veterinaria`);

ALTER TABLE `disponibilidad` ADD FOREIGN KEY (`veterinario_id`) REFERENCES `veterinario` (`id_veterinario`);

ALTER TABLE `cita` ADD FOREIGN KEY (`disponibilidad_id`) REFERENCES `disponibilidad` (`id_disponibilidad`);

ALTER TABLE `cita` ADD FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id_cliente`);

ALTER TABLE `pedido` ADD FOREIGN KEY (`cliente_id1`) REFERENCES `cliente` (`id_cliente`);

ALTER TABLE `pedido` ADD FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id_producto`);

ALTER TABLE `factura` ADD FOREIGN KEY (`pedido_id1`) REFERENCES `pedido` (`id_pedido`);

ALTER TABLE `factura` ADD FOREIGN KEY (`domiciliario_id`) REFERENCES `domiciliario` (`id_domiciliario`);
